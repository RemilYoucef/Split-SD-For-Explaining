from distutils.core import setup

setup(
  name = 'splitsd',
  packages = ['splitsd'], # this must be the same as the name above
  version = '0.1',
  description = 'Split SD For Explaining',
  author = 'Youcef REMIL',
  author_email = 'fy_remil@esi.dz',
  url = 'https://github.com/RemilYoucef/Split-SD-For-Explaining'
)